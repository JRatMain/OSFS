# Files will be created and altered with this constructor.
class File:
    def __init__(self, name):
        self.name = name
        self.content = ""
